/*<<<<<<<<<<< SSD_interface.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#ifndef _SSD_INTERFACE_H_
#define _SSD_INTERFACE_H_

void SSD_voidInit(void);

void SSD_Display_1_Number(u8 number);

void SSD_Display_2_Numbers(u8 number);


#endif
