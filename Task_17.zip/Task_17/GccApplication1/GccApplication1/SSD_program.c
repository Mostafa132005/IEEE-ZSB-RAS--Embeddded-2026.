/*<<<<<<<<<<< SSD_program.c>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#define  F_CPU 16000000
#include <util/delay.h>

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "GPIO_interface.h"
#include "SSD_config.h"
#include "SSD_interface.h"
#include "SSD_private.h"

u8 SSD_Cathode [10] = {
	0b00111111, //0
	0b00000110,
	0b01011011,
	0b01001111,
	0b01100110,
	0b01101101,
	0b01111101,
	0b00000111,
	0b01111111,
	0b01101111  //9
};

void SSD_voidInit(void)
{
	/* Enable pins as output */
	GPIO_enumSetPinDirection(SSD_EN_PORT, SSD_EN1, PIN_OUTPUT);
	GPIO_enumSetPinDirection(SSD_EN_PORT, SSD_EN2, PIN_OUTPUT);

	/* Segment ports as output */
	GPIO_enumSetPortDirection(SSD1_PORT, PORT_OUTPUT);
	GPIO_enumSetPortDirection(SSD2_PORT, PORT_OUTPUT);

	/* Start with both SSDs disabled */
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN1, PIN_HIGH);
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN2, PIN_HIGH);
}

void SSD_Display_1_Number(u8 number)
{
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN1, PIN_LOW);  // EN SSD1
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN2, PIN_HIGH); // DISABLE SSD2
	GPIO_enumSetPortValue(SSD1_PORT, SSD_Cathode[number]);
}

void SSD_Display_2_Numbers(u8 number)
{
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN1, PIN_LOW);  // EN SSD1
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN2, PIN_HIGH); // DISABLE SSD2
	GPIO_enumSetPortValue(SSD1_PORT, SSD_Cathode[number/10]);
	_delay_ms(80);

	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN1, PIN_HIGH); // DISABLE SSD1
	GPIO_enumSetPinValue(SSD_EN_PORT, SSD_EN2, PIN_LOW);  // EN SSD2
	GPIO_enumSetPortValue(SSD2_PORT, SSD_Cathode[number%10]);
	_delay_ms(60);
}
