/*<<<<<<<<<<< SSD_private.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#ifndef _SSD_PRIVATE_H_
#define _SSD_PRIVATE_H_

#define SSD_DIGITS_COUNT   10






#endif
