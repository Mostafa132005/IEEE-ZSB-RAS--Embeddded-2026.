/*<<<<<<<<<<< SSD_config.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#ifndef _SSD_CONFIG_H_
#define _SSD_CONFIG_H_

/* Enable pins port/pins (use GPIO layer macros, not raw registers) */
#define SSD_EN_PORT   GPIO_PORTA
#define SSD_EN1       PIN0
#define SSD_EN2       PIN1

/* Ports carrying the 7-segment cathode pattern */
#define SSD1_PORT   GPIO_PORTC
#define SSD2_PORT   GPIO_PORTC




#endif
