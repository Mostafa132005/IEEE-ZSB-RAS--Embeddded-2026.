/*<<<<<<<<<<< LED_interface.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#ifndef LED_INTERFACE_H_ 
#define LED_INTERFACE_H_ 


//Port Defines
#define LED_PORTA   0
#define LED_PORTB   1
#define LED_PORTC   2
#define LED_PORTD   3


//Pin Defines
#define LED_PIN0     0
#define LED_PIN1     1
#define LED_PIN2     2
#define LED_PIN3     3
#define LED_PIN4     4
#define LED_PIN5     5
#define LED_PIN6     6
#define LED_PIN7     7

//PIN States
#define ACTIVE_HIGH  1
#define ACTIVE_LOW   0


typedef struct{
    u8 pin ;
    u8 port ;
    u8 Active_State;
}LED_Type;

void LED_voidInti(LED_Type LED_Configrations);
void LED_voidON(LED_Type LED_Configrations);
void LED_voidOFF(LED_Type LED_Configrations);
void LED_voidTOGGEL(LED_Type LED_Configrations);


#endif