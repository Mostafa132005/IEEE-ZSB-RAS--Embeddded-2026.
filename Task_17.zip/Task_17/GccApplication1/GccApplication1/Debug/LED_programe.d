LED_programe.d LED_programe.o: .././LED_programe.c .././BIT_MATH.H \
 .././STD_TYPES.H .././LED_interface.h .././GPIO_interface.h

.././BIT_MATH.H:

.././STD_TYPES.H:

.././LED_interface.h:

.././GPIO_interface.h:
