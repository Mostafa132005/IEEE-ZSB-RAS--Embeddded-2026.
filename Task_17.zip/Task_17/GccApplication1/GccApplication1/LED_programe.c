#include "BIT_MATH.H"
#include "STD_TYPES.H"
#include "LED_interface.h"
#include "GPIO_interface.h"

void LED_voidInti(LED_Type LED_Configrations){
    GPIO_enumSetPinDirection   (LED_Configrations.port, LED_Configrations.pin, PIN_OUTPUT);
}


void LED_voidON(LED_Type LED_Configrations){
    if(LED_Configrations.Active_State == ACTIVE_HIGH)
    {
        GPIO_enumSetPinValue(LED_Configrations.port, LED_Configrations.pin, PIN_HIGH);
    }else if(LED_Configrations.Active_State == ACTIVE_LOW)
    {
        GPIO_enumSetPinValue(LED_Configrations.port, LED_Configrations.pin, PIN_LOW);
    }
}


void LED_voidOFF(LED_Type LED_Configrations){
    if(LED_Configrations.Active_State == ACTIVE_HIGH)
    {
        GPIO_enumSetPinValue(LED_Configrations.port, LED_Configrations.pin, PIN_LOW);
    }else if(LED_Configrations.Active_State == ACTIVE_LOW)
    {
        GPIO_enumSetPinValue(LED_Configrations.port, LED_Configrations.pin, PIN_HIGH);
    }    
}


void LED_voidTOGGEL(LED_Type LED_Configrations){
    GPIO_enumTogPinValue(LED_Configrations.port, LED_Configrations.pin);
}