/*<<<<<<<<<<< GPIO_private.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : MCAL 
*/

#ifndef GPIO_PRIVATE
#define GPIO_PRIVATE

/* Group A */
#define PORTA *((volatile u8*) 0x1B)
#define DDRA  *((volatile u8*) 0x1A)
#define PINA  *((volatile u8*) 0x19)

/* Group B */
#define PORTB *((volatile u8*) 0x18)
#define DDRB  *((volatile u8*) 0x17)
#define PINB  *((volatile u8*) 0x16)

/* Group C */
#define PORTC *((volatile u8*) 0x15)
#define DDRC  *((volatile u8*) 0x14)
#define PINC  *((volatile u8*) 0x13)

/* Group D */
#define PORTD *((volatile u8*) 0x12)
#define DDRD  *((volatile u8*) 0x11)
#define PIND  *((volatile u8*) 0x10)

#endif