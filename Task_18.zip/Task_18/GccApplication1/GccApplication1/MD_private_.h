/*<<<<<<<<<<< MD_private.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#ifndef _MD_PRIVATE_H_
#define _MD_PRIVATE_H_






#endif
