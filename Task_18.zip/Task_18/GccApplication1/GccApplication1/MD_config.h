/*<<<<<<<<<<< MD_config.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#ifndef _MD_CONFIG_H_
#define _MD_CONFIG_H_

#define MOTOR_PORT    GPIO_PORTC

#define RM_DIR_PIN    PIN0
#define RM_EN_PIN     PIN1

#define LM_DIR_PIN    PIN2
#define LM_EN_PIN     PIN3

#endif /* _MD_CONFIG_H_ */
