/*<<<<<<<<<<< GPIO_program.c>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : MCAL 
*      SWC   : GPIO/DIO
*/

#include "STD_TYPES.h"
#include "BIT_MATH.H"

#include "GPIO_private.h"
#include "GPIO_interface.h"

GPIO_ErrorStatus GPIO_enumSetPinDirection   (u8 Copy_u8PORT, u8 Copy_u8Pin, u8 Copy_u8Direction)
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;

    if(Copy_u8PORT <= GPIO_PORTD && Copy_u8Pin <= PIN7){
        if(Copy_u8Direction == PIN_OUTPUT){
            switch(Copy_u8PORT){
                case GPIO_PORTA : SET_BIT(DDRA,Copy_u8Pin);break;
                case GPIO_PORTB : SET_BIT(DDRB,Copy_u8Pin);break;
                case GPIO_PORTC : SET_BIT(DDRC,Copy_u8Pin);break;
                case GPIO_PORTD : SET_BIT(DDRD,Copy_u8Pin);break;
            }
        }
        else if(Copy_u8Direction == PIN_INPUT){
            switch(Copy_u8PORT){
                case GPIO_PORTA : CLR_BIT(DDRA,Copy_u8Pin);break;
                case GPIO_PORTB : CLR_BIT(DDRB,Copy_u8Pin);break;
                case GPIO_PORTC : CLR_BIT(DDRC,Copy_u8Pin);break;
                case GPIO_PORTD : CLR_BIT(DDRD,Copy_u8Pin);break;
            }
        }
        else
        {
            LOC_Statu = GPIO_NOK;
        }       
    }
    else{
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}

GPIO_ErrorStatus GPIO_enumSetPinValue      (u8 Copy_u8PORT, u8 Copy_u8Pin, u8 Copy_u8Value)
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;

    if(Copy_u8PORT <= GPIO_PORTD && Copy_u8Pin <= PIN7)
    {
        if(Copy_u8Value == PIN_HIGH)
        {
            switch(Copy_u8PORT)
            {
                case GPIO_PORTA: SET_BIT(PORTA, Copy_u8Pin);break;
                case GPIO_PORTB: SET_BIT(PORTB, Copy_u8Pin);break;
                case GPIO_PORTC: SET_BIT(PORTC, Copy_u8Pin);break;
                case GPIO_PORTD: SET_BIT(PORTD, Copy_u8Pin);break;
            }
        }
        else if(Copy_u8Value == PIN_LOW)
        {
            switch(Copy_u8PORT)
            {
                case GPIO_PORTA: CLR_BIT(PORTA, Copy_u8Pin);break;
                case GPIO_PORTB: CLR_BIT(PORTB, Copy_u8Pin);break;
                case GPIO_PORTC: CLR_BIT(PORTC, Copy_u8Pin);break;
                case GPIO_PORTD: CLR_BIT(PORTD, Copy_u8Pin);break;
            }
        }
        else 
        {
            LOC_Statu = GPIO_NOK;
        }
    }
    else 
    {
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}

GPIO_ErrorStatus GPIO_enumGetPinValue       (u8 Copy_u8PORT, u8 Copy_u8Pin, u8 * Copy_PtrData)
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;
    if(Copy_u8PORT <= GPIO_PORTD && Copy_u8Pin <= PIN7)
    {
        switch(Copy_u8PORT)
        {
            case GPIO_PORTA : * Copy_PtrData = GET_BIT(PINA,Copy_u8Pin);break;
            case GPIO_PORTB : * Copy_PtrData = GET_BIT(PINB,Copy_u8Pin);break;
            case GPIO_PORTC : * Copy_PtrData = GET_BIT(PINC,Copy_u8Pin);break;
            case GPIO_PORTD : * Copy_PtrData = GET_BIT(PIND,Copy_u8Pin);break;
        }
    }
    else
    {
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}

GPIO_ErrorStatus GPIO_enumTogPinValue (u8 Copy_u8PORT, u8 Copy_u8Pin)
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;
    if(Copy_u8PORT <= GPIO_PORTD && Copy_u8Pin <= PIN7)
    {
        switch(Copy_u8PORT)
        {
            case GPIO_PORTA : TOG_BIT(PORTA,Copy_u8Pin);break;
            case GPIO_PORTB : TOG_BIT(PORTB,Copy_u8Pin);break;
            case GPIO_PORTC : TOG_BIT(PORTC,Copy_u8Pin);break;
            case GPIO_PORTD : TOG_BIT(PORTD,Copy_u8Pin);break;
        }
    }
    else
    {
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}


GPIO_ErrorStatus GPIO_enumSetPortDirection   (u8 Copy_u8PORT, u8 Copy_u8Direction)
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;
    if(Copy_u8PORT <= GPIO_PORTD)
    {
        switch(Copy_u8PORT)
        {
            case     GPIO_PORTA : DDRA = Copy_u8Direction;break;
            case     GPIO_PORTB : DDRB = Copy_u8Direction;break;
            case     GPIO_PORTC : DDRC = Copy_u8Direction;break;
            case     GPIO_PORTD : DDRD = Copy_u8Direction;break;
            default: LOC_Statu = GPIO_NOK; 
        }
    }
    else
    {
        LOC_Statu = GPIO_NOK;
    }
    
    return LOC_Statu; 
}


GPIO_ErrorStatus GPIO_enumSetPortValue       (u8 Copy_u8PORT, u8 Copy_u8Value    )
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;
    if((Copy_u8PORT <= GPIO_PORTD) && ((Copy_u8Value == 255) || (Copy_u8Value == PORT_LOW) || (Copy_u8Value == PORT_HIGH) ) )
    {
      switch(Copy_u8PORT)
      {
        case     GPIO_PORTA: PORTA = Copy_u8Value;break;
        case     GPIO_PORTB: PORTB = Copy_u8Value;break;
        case     GPIO_PORTC: PORTC = Copy_u8Value;break;
        case     GPIO_PORTD: PORTD = Copy_u8Value;break;
        default: LOC_Statu = GPIO_NOK;
      }  
    }
    else
    {
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}

GPIO_ErrorStatus GPIO_enumGetPortValue       (u8 Copy_u8PORT, u8 * Copy_PtrData )
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;
    if(Copy_u8PORT <= GPIO_PORTD)
    {
        switch(Copy_u8PORT)
        {
            case GPIO_PORTA: * Copy_PtrData = PINA; break;
            case GPIO_PORTB: * Copy_PtrData = PINB; break;
            case GPIO_PORTC: * Copy_PtrData = PINC; break;
            case GPIO_PORTD: * Copy_PtrData = PIND; break;
            default: LOC_Statu = GPIO_NOK;
        }
    }
    else
    {
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}

GPIO_ErrorStatus GPIO_enumTogPortValue       (u8 Copy_u8PORT) 
{
    GPIO_ErrorStatus LOC_Statu = GPIO_OK;
    if(Copy_u8PORT <= GPIO_PORTD)
    {
        switch(Copy_u8PORT)
        {
            case GPIO_PORTA : PORTA = ~PORTA;break;
            case GPIO_PORTB : PORTB = ~PORTB;break;
            case GPIO_PORTC : PORTC = ~PORTC;break;
            case GPIO_PORTD : PORTD = ~PORTD;break;
            default: LOC_Statu = GPIO_NOK;
        }
    }
    else
    {
        LOC_Statu = GPIO_NOK;
    }
    return LOC_Statu;
}