/*<<<<<<<<<<< GPIO_config.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : MCAL 
*/

#ifndef GPIO_CONFIGE
#define GPIO_CONFIGE


#endif