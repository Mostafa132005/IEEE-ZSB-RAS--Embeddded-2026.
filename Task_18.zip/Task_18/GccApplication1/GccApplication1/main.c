/*
 * GccApplication1.c
 *
 * Created: 07/27/2026 00:40:23
 * Author : Mostafa ElRmady
 */ 

#include <avr/io.h>

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "GPIO_interface.h"
#include "MD_interface.h"

#define SW_PORT         GPIO_PORTA
#define SW_STOP_PIN     PIN0
#define SW_FORWARD_PIN  PIN1
#define SW_BACKWARD_PIN PIN2
#define SW_LEFT_PIN     PIN3
#define SW_RIGHT_PIN    PIN4

#define PRESSED         PIN_HIGH

int main(void)
{
	u8 local_u8StopState     = 0;
	u8 local_u8ForwardState  = 0;
	u8 local_u8BackwardState = 0;
	u8 local_u8LeftState     = 0;
	u8 local_u8RightState    = 0;

	MD_vInit();

	GPIO_enumSetPinDirection(SW_PORT, SW_STOP_PIN,     PIN_INPUT);
	GPIO_enumSetPinDirection(SW_PORT, SW_FORWARD_PIN,  PIN_INPUT);
	GPIO_enumSetPinDirection(SW_PORT, SW_BACKWARD_PIN, PIN_INPUT);
	GPIO_enumSetPinDirection(SW_PORT, SW_LEFT_PIN,     PIN_INPUT);
	GPIO_enumSetPinDirection(SW_PORT, SW_RIGHT_PIN,    PIN_INPUT);

	while(1)
	{
		GPIO_enumGetPinValue(SW_PORT, SW_STOP_PIN,     &local_u8StopState);
		GPIO_enumGetPinValue(SW_PORT, SW_FORWARD_PIN,  &local_u8ForwardState);
		GPIO_enumGetPinValue(SW_PORT, SW_BACKWARD_PIN, &local_u8BackwardState);
		GPIO_enumGetPinValue(SW_PORT, SW_LEFT_PIN,     &local_u8LeftState);
		GPIO_enumGetPinValue(SW_PORT, SW_RIGHT_PIN,    &local_u8RightState);

		if(local_u8StopState == PRESSED)
		{
			MD_vStop();
		}
		else if(local_u8ForwardState == PRESSED)
		{
			MD_vForward();
		}
		else if(local_u8BackwardState == PRESSED)
		{
			MD_vBackward();
		}
		else if(local_u8LeftState == PRESSED)
		{
			MD_vTurnLeft();
		}
		else if(local_u8RightState == PRESSED)
		{
			MD_vTurnRight();
		}
	}
	
	return 0;
}