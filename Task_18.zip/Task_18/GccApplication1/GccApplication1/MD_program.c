/*<<<<<<<<<<< MD_program.c>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : HAL 
*/

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "GPIO_interface.h"

#include "MD_config.h"
#include "MD_interface.h"

void MD_vInit(void)
{
	GPIO_enumSetPinDirection(MOTOR_PORT, RM_DIR_PIN, PIN_OUTPUT);
	GPIO_enumSetPinDirection(MOTOR_PORT, RM_EN_PIN,  PIN_OUTPUT);
	GPIO_enumSetPinDirection(MOTOR_PORT, LM_DIR_PIN, PIN_OUTPUT);
	GPIO_enumSetPinDirection(MOTOR_PORT, LM_EN_PIN,  PIN_OUTPUT);
	
	MD_vStop();
}

void MD_vStop(void)
{
	GPIO_enumSetPinValue(MOTOR_PORT, RM_EN_PIN, PIN_LOW);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_EN_PIN, PIN_LOW);
}

void MD_vForward(void)
{
	GPIO_enumSetPinValue(MOTOR_PORT, RM_DIR_PIN, PIN_LOW);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_DIR_PIN, PIN_LOW);
	
	GPIO_enumSetPinValue(MOTOR_PORT, RM_EN_PIN, PIN_HIGH);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_EN_PIN, PIN_HIGH);
}

void MD_vBackward(void)
{
	GPIO_enumSetPinValue(MOTOR_PORT, RM_DIR_PIN, PIN_HIGH);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_DIR_PIN, PIN_HIGH);
	
	GPIO_enumSetPinValue(MOTOR_PORT, RM_EN_PIN, PIN_HIGH);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_EN_PIN, PIN_HIGH);
}

void MD_vTurnRight(void)
{
	GPIO_enumSetPinValue(MOTOR_PORT, LM_DIR_PIN, PIN_LOW);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_EN_PIN, PIN_HIGH);
	
	GPIO_enumSetPinValue(MOTOR_PORT, RM_DIR_PIN, PIN_HIGH);
	GPIO_enumSetPinValue(MOTOR_PORT, RM_EN_PIN, PIN_HIGH);
}

void MD_vTurnLeft(void)
{
	GPIO_enumSetPinValue(MOTOR_PORT, RM_DIR_PIN, PIN_LOW);
	GPIO_enumSetPinValue(MOTOR_PORT, RM_EN_PIN, PIN_HIGH);
	
	GPIO_enumSetPinValue(MOTOR_PORT, LM_DIR_PIN, PIN_HIGH);
	GPIO_enumSetPinValue(MOTOR_PORT, LM_EN_PIN, PIN_HIGH);
}
