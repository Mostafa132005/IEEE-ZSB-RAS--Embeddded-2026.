GPIO_program.d GPIO_program.o: .././GPIO_program.c .././STD_TYPES.h \
 .././BIT_MATH.H .././GPIO_private.h .././GPIO_interface.h

.././STD_TYPES.h:

.././BIT_MATH.H:

.././GPIO_private.h:

.././GPIO_interface.h:
