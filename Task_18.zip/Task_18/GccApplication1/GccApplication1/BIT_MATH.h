/*<<<<<<<<<<< BIT_MATH.h >>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : LIB 
*/

#ifndef BIT_MATH_H_
#define BIT_MATH_H_

#define SET_BIT(reg,bit)       reg|=(1<<bit)            //Make Bit = 1
#define CLR_BIT(reg,bit)       reg&=(~(1<<bit))         //Make Bit = 0  
#define TOG_BIT(reg,bit)       reg^=(1<<bit)            //Invert Bit Value  
#define GET_BIT(reg,bit)       (reg&(1<<bit))>>bit      //Read Bit

#define IS_SET_BIT(reg,bit)    (reg&(1<<bit))>>bit      //Check Bit == 1
#define IS_CLE_BIT(reg,bit)    !((reg&(1<<bit))>>bit)   //Check Bit == 0

#endif  