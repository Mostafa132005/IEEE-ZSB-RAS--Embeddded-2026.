/*<<<<<<<<<<< GPIO_interface.h>>>>>>>>>>>>>>
*      Author: Mostafa ELRmady
*      Layer : MCAL 
*/

#ifndef GPIO_INTERFACE
#define GPIO_INTERFACE

typedef enum {
    GPIO_OK,
    GPIO_NOK
}GPIO_ErrorStatus;

#define PIN_OUTPUT 1
#define PIN_INPUT  0

#define PIN_HIGH   1
#define PIN_LOW    0

#define PORT_OUTPUT 0xff
#define PORT_INPUT   0

#define PORT_HIGH    0xff
#define PORT_LOW     0

#define GPIO_PORTA 0
#define GPIO_PORTB 1
#define GPIO_PORTC 2
#define GPIO_PORTD 3

#define PIN0 0
#define PIN1 1
#define PIN2 2
#define PIN3 3
#define PIN4 4
#define PIN5 5
#define PIN6 6
#define PIN7 7

GPIO_ErrorStatus GPIO_enumSetPinDirection   (u8 Copy_u8PORT, u8 Copy_u8Pin, u8 Copy_u8Direction);
GPIO_ErrorStatus GPIO_enumSetPinValue       (u8 Copy_u8PORT, u8 Copy_u8Pin, u8 Copy_u8Value    );
GPIO_ErrorStatus GPIO_enumGetPinValue       (u8 Copy_u8PORT, u8 Copy_u8Pin, u8 * Copy_PtrData  );
GPIO_ErrorStatus GPIO_enumTogPinValue       (u8 Copy_u8PORT, u8 Copy_u8Pin                     );

GPIO_ErrorStatus GPIO_enumSetPortDirection   (u8 Copy_u8PORT, u8 Copy_u8Direction);
GPIO_ErrorStatus GPIO_enumSetPortValue       (u8 Copy_u8PORT, u8 Copy_u8Value    );
GPIO_ErrorStatus GPIO_enumGetPortValue       (u8 Copy_u8PORT, u8 * Copy_PtrData  );
GPIO_ErrorStatus GPIO_enumTogPortValue       (u8 Copy_u8PORT                     );


#endif